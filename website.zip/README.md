Spectal Talent Management
By Abhinav Agrawal | abhinavagrawal.in


Do not touch the "assets" folder

Images:
	All images in the "assets/images" folder

	Logo : logo.png
	Home Page has 5 images : 
	home1.jpg
	home2.jpg
	home3.jpg
	home4.jpg
	home5.jpg

	Backgrounds for other sections:-

		About Us : about.jpg
		Services uses 2 images : service1.jpg , service2.jpg
		Artists currently uses 1 image : artist1.jpg
		Gallery:-
			Main background: gallery_back.jpg
			Thumbnails : in the "images/thumbs" folder. named as 01.jpg, 02.jpg and so on
			Full size : in the "images/fulls" folder. Same naming convention.
		Contact Us : contact.jpg
